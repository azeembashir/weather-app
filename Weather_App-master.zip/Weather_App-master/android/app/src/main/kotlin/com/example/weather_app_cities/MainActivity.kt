package com.example.weather_app_cities

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
