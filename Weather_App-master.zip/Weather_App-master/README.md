<h1>Flutter Weather App</h1>
<p>This project helps to understand and learned about to fetching the Weather updates by using flutter.</p>
